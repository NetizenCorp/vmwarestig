
class test_class(object):

    def __init__(self):
        self.test1 = None

    def print_var(self):
        print self.test1



t = test_class()
t.test1 = 'hello'
t.print_var()
