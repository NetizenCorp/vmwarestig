try:
    # for Python2
    from Tkinter import *   ## notice capitalized T in Tkinter
except ImportError:
    # for Python3
    from tkinter import *   ## notice lowercase 't' in tkinter here

from netaddr import *
import tkMessageBox
from pyVim.connect import SmartConnect
import ssl
import os

    
class MyFirstGUI:
    def __init__(self, master):
        self.master = master
        master.geometry('350x200')
        master.resizable(False, False)
        master.title("VMWare ESXi STIG Checker")

        label_ip_address = Label(master, text="IP Address:")         
        label_ip_address.place(x=0, y=0)
        self.text_ip_address = Entry(master, width=25)
        self.text_ip_address.place(x=80, y=0)

        label_username = Label(master, text="Username:")
        label_username.place(x=0, y=25)
        self.text_username = Entry(master, width=25)
        self.text_username.place(x=80, y=25)

        label_password = Label(master, text="Password:")
        label_password.place(x=0, y=50)
        self.text_password = Entry(master, show="*", width=25)
        self.text_password.place(x=80, y=50)

        button_connect = Button(master, text="Connect", command=self.greet)
        button_connect.place(x=0, y=75)

        button_close = Button(master, text="Close", command=self.master.destroy)
        button_close.place(x=70, y=75)

    def greet(self):
        if self.text_ip_address.get() == "":
            tkMessageBox.showerror(title="error",message="Enter a IP Address",parent=self.master)
        else:
            if valid_ipv4(self.text_ip_address.get()):
                s=ssl.SSLContext(ssl.PROTOCOL_TLSv1)
                s.verify_mode=ssl.CERT_NONE
                si= SmartConnect(host=self.text_ip_address.get(),
                                 user=self.text_username.get(),
                                 pwd=self.text_password.get(),
                                 sslContext=s)
                aboutInfo=si.content.about

                print(si.CurrentTime())
                 
                print("Product Name:",aboutInfo.fullName)
                print("Product Build:",aboutInfo.build)
                print("Product Unique Id:",aboutInfo.instanceUuid)
                print("Product Version:",aboutInfo.version)
                print("Product Base OS:",aboutInfo.osType)
                print("Product vendor:",aboutInfo.vendor)
                
            else:
                tkMessageBox.showerror(title="error",message="Invalid IP Address",parent=self.master)
        
print(os.path.dirname(os.path.abspath(__file__)))              
root = Tk()
my_gui = MyFirstGUI(root)
root.mainloop()
