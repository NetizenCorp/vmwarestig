from paramiko import client

class ssh:
    client = None
 
    def __init__(self, address, username, password):
        print("Connecting to server.")
        self.client = client.SSHClient()
        self.client.set_missing_host_key_policy(client.AutoAddPolicy())
        self.client.connect(address, username=username, password=password, look_for_keys=False)
 
    def sendCommand(self, command):
        if(self.client):
            stdin, stdout, stderr = self.client.exec_command(command)
            while not stdout.channel.exit_status_ready():
                # Print data when available
                if stdout.channel.recv_ready():
                    alldata = stdout.channel.recv(1024)
                    prevdata = b"1"
                    while prevdata:
                        prevdata = stdout.channel.recv(1024)
                        alldata += prevdata
 
                    print(str(alldata))
        else:
            print("Connection not opened.")

connection = ssh("10.0.2.5", "root", "Free$411")
#V-63187
#CAT II
connection.sendCommand('grep -i "^Banner" /etc/ssh/sshd_config')
#V-63189
#CAT II
connection.sendCommand('grep -i "^Ciphers" /etc/ssh/sshd_config')
#V-63191
#CAT I
connection.sendCommand('grep -i "^Protocol" /etc/ssh/sshd_config')
#V-63193
#CAT II
connection.sendCommand('grep -i "^IgnoreRhosts" /etc/ssh/sshd_config')
#V-63195
#CAT II
connection.sendCommand('grep -i "^HostbasedAuthentication" /etc/ssh/sshd_config')
#V-63197
#CAT III
connection.sendCommand('grep -i "^PermitRootLogin" /etc/ssh/sshd_config')
#V-63199
#CAT I
connection.sendCommand('grep -i "^PermitEmptyPasswords" /etc/ssh/sshd_config')
#V-63201
#CAT II
connection.sendCommand('grep -i "^PermitUserEnvironment" /etc/ssh/sshd_config')
#V-63203
#CAT II
connection.sendCommand('grep -i "^MACs" /etc/ssh/sshd_config')
#V-63205
#CAT III
connection.sendCommand('grep -i "^GSSAPIAuthentication" /etc/ssh/sshd_config')
#V-63207
#CAT III
connection.sendCommand('grep -i "^KerberosAuthentication" /etc/ssh/sshd_config')
#V-63209
#CAT II
connection.sendCommand('grep -i "^StrictModes" /etc/ssh/sshd_config')
#V-63211
#CAT II
connection.sendCommand('grep -i "^Compression" /etc/ssh/sshd_config')
#V-63213
#CAT III
connection.sendCommand('grep -i "^GatewayPorts" /etc/ssh/sshd_config')
#V-63215
#CAT II
connection.sendCommand('grep -i "^X11Forwarding" /etc/ssh/sshd_config')
#V-63217
#CAT II
connection.sendCommand('grep -i "^AcceptEnv" /etc/ssh/sshd_config')
#V-63219
#CAT II
connection.sendCommand('grep -i "^PermitTunnel" /etc/ssh/sshd_config')
#V-63221
#CAT III
connection.sendCommand('grep -i "^ClientAliveCountMax" /etc/ssh/sshd_config')
#V-63223
#CAT III
connection.sendCommand('grep -i "^ClientAliveInterval" /etc/ssh/sshd_config')
#V-63225
#CAT II
connection.sendCommand('grep -i "^MaxSessions" /etc/ssh/sshd_config')
#V-63227
#CAT II
connection.sendCommand('ls -la /etc/ssh/keys-root/authorized_keys')
#V-63233
#CAT II
connection.sendCommand('grep -i "^password" /etc/pam.d/passwd | grep sufficient')
#V-63235
#CAT II
connection.sendCommand('grep -i "^password" /etc/pam.d/passwd | grep sufficient')
#V-63501
#CAT II
connection.sendCommand('grep -i "^Ciphers" /etc/ssh/sshd_config')