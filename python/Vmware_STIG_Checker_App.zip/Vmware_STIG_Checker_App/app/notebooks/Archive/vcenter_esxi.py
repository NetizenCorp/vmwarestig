import os
import subprocess

def check_powershell():
    return (os.path.isfile('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'))

def check_poercli():
    return (os.path.isfile('C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Scripts\Initialize-PowerCLIEnvironment.ps1')) 

def esxi_command(command):
    COMMAND_LINE = 'powershell'
    powershell = subprocess.Popen(COMMAND_LINE, shell=True,
                                       stdin=subprocess.PIPE,
                                       stderr=subprocess.STDOUT,
                                       stdout=subprocess.PIPE)
    output = powershell.stdout.readline()

    powershell.stdin.write('Set-Location "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Scripts"\r\n')
    powershell.stdin.write('.\Initialize-PowerCLIEnvironment.ps1\r\n')
    powershell.stdin.flush()
    powershell.stdin.write("Connect-VIServer 10.0.2.6 -Port 443 -User Administrator@vsphere.local -Password 'Free$411'\r\n")
    powershell.stdin.flush()
    powershell.stdin.write(command)
    #while powershell.poll() is None:
    #    l = powershell.stdout.readline()
    #    print l
    #    print ""
    #    print "$$$"
    #print powershell.stdout.read()
    
    output = powershell.stdout.readline()
    out = powershell.communicate()[0]
    return(out)


print check_poercli()
print check_powershell()
'''
print ('V-63949')
passed_command = 'Get-VIPermission | Sort Role | Select Role,Principal,Entity,Propagate,IsGroup | FT -Auto\r\n'
print esxi_command(passed_command).split(passed_command)[1].split(' C:\> ')[0]

print ('V-63951')
passed_command = 'Get-VDSwitch | select Name,@{N="NIOC Enabled";E={$_.ExtensionData.config.NetworkResourceManagementEnabled}}\r\n'
print esxi_command(passed_command).split(passed_command)[1].split(' C:\> ')[0]

print ('V-63953')
passed_command = 'Get-AlarmDefinition | Where {$_.ExtensionData.Info.Expression.Expression.EventTypeId -eq "esx.problem.vmsyslogd.remote.failure"} | Select Name,Enabled,@{N="EventTypeId";E={$_.ExtensionData.Info.Expression.Expression.EventTypeId}}\r\n'
print esxi_command(passed_command).split(passed_command)[1].split(' C:\> ')[0]

print ('V-63961')
passed_command = '$vds = Get-VDSwitch\r\n$vds.ExtensionData.Config.HealthCheckConfig\r\n'
split_command = '$vds.ExtensionData.Config.HealthCheckConfig\r\n'
print esxi_command(passed_command).split(split_command)[1].split(' C:\> ')[0]

print ('V-63963, V-63965, V-63967')
passed_command = 'Get-VDSwitch | Get-VDSecurityPolicy\r\n'
print esxi_command(passed_command).split(passed_command)[1].split(' C:\> ')[0]
passed_command = 'Get-VDPortgroup | ?{$_.IsUplink -eq $false} | Get-VDSecurityPolicy\r\n'
print esxi_command(passed_command).split(passed_command)[1].split(' C:\> ')[0]

print ('V-63969')
passed_command = 'Get-VDSwitch | select Name,@{N="NetFlowCollectorIPs";E={$_.ExtensionData.config.IpfixConfig.CollectorIpAddress}}\r\n'
print esxi_command(passed_command).split(passed_command)[1].split(' C:\> ')[0]
'''

print ('V-63971')
passed_command = ('Get-VDPortgroup | Get-View | \n' +
'Select Name, \n' +
'@{N="VlanOverrideAllowed";E={$_.Config.Policy.VlanOverrideAllowed}}, \n' +
'@{N="UplinkTeamingOverrideAllowed";E={$_.Config.Policy.UplinkTeamingOverrideAllowed}}, \n' +
'@{N="SecurityPolicyOverrideAllowed";E={$_.Config.Policy.SecurityPolicyOverrideAllowed}}, \n' +
'@{N="IpfixOverrideAllowed";E={$_.Config.Policy.IpfixOverrideAllowed}}, \n' +
'@{N="BlockOverrideAllowed";E={$_.Config.Policy.BlockOverrideAllowed}}, \n' +
'@{N="ShapingOverrideAllowed";E={$_.Config.Policy.ShapingOverrideAllowed}}, \n' +
'@{N="VendorConfigOverrideAllowed";E={$_.Config.Policy.VendorConfigOverrideAllowed}}, \n' +
'@{N="TrafficFilterOverrideAllowed";E={$_.Config.Policy.TrafficFilterOverrideAllowed}}, \n' +
'@{N="PortConfigResetAtDisconnect";E={$_.Config.Policy.PortConfigResetAtDisconnect}} | Sort Name')
print esxi_command(passed_command) #.split(passed_command) #[1].split(' C:\> ')[0]
