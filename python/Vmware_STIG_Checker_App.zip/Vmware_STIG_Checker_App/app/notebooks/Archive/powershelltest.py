import subprocess
import os
## 
##def callps1():
## file_dir = os.path.dirname(os.path.abspath(__file__))
##    
## #powerShellPath = r'C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe'
##
## powerShellPath = r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -noe -c ". \"C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Scripts\Initialize-PowerCLIEnvironment.ps1\" $true"'
## powerShellCmd = file_dir + "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Scripts\Initialize-PowerCLIEnvironment.ps1"
## 
## p = subprocess.Popen([powerShellPath, '-ExecutionPolicy', 'Unrestricted', powerShellCmd, 'HELLO', 'WORLD']
## , stdout=subprocess.PIPE, stderr=subprocess.PIPE)
## output, error = p.communicate()
##
## rc = p.returncode
## print "Return code given to Python script is: " + str(rc)
## print "\n\nstdout:\n\n" + str(output)
## print "\n\nstderr: " + str(error)
## 
###Test
##callps1()

print (os.environ["ProgramFiles(x86)"] + '\VMware\Infrastructure\PowerCLI\Scripts\Initialize-PowerCLIEnvironment.ps1')

powerShellPath = r'C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe'
powerCLIPath = os.environ["ProgramFiles(x86)"] + r'\VMware\Infrastructure\PowerCLI\Scripts\Initialize-PowerCLIEnvironment.ps1'

#subprocess.call(['C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe ' +
#                 os.environ["ProgramFiles(x86)"] + '\VMware\Infrastructure\PowerCLI\Scripts\Initialize-PowerCLIEnvironment.ps1'])


p = subprocess.Popen([powerShellPath, '-ExecutionPolicy', 'bypass','-File', powerCLIPath], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
output, error = p.communicate()
rc = p.returncode
print "Return code given to Python script is: " + str(rc)
print "\n\nstdout:\n\n" + str(output)
print "\n\nstderr: " + str(error)
p.stdout.write('Connect-VIServer')


