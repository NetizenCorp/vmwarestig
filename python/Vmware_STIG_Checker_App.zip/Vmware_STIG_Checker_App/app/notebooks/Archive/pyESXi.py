# VMware vSphere Python SDK, pyvmomi
# Simple script to get vCenter server product details
 
from pyVim.connect import SmartConnect
import ssl
s=ssl.SSLContext(ssl.PROTOCOL_TLSv1)
s.verify_mode=ssl.CERT_NONE
si= SmartConnect(host="10.0.3.10", user="root", pwd="free$411", sslContext=s)
aboutInfo=si.content.about

print(si.CurrentTime())
 
print ("Product Name:",aboutInfo.fullName)
print("Product Build:",aboutInfo.build)
print("Product Unique Id:",aboutInfo.instanceUuid)
print("Product Version:",aboutInfo.version)
print("Product Base OS:",aboutInfo.osType)
print("Product vendor:",aboutInfo.vendor)
